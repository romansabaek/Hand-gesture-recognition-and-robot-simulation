#include "../include/opencv/dh_cam.h"


using namespace std;
using namespace cv;
using namespace BDH_CAM;


ros::Publisher vision_pub;

IplImage *frame,
                *YCR_image_result,*Circle, //2
                *average_image, *sgm,*tmp,*msk,*lower,*upper,*sub_skin, *skin,//background 8
                * src_gray, *roi_image,*sub_roi, //3
                *labeled_image, //1
                *sub_image, *sub_image_final =0; //2

CvCapture * input_CAM = 0;
CvSize size;

//camshift
IplImage *image, *hue, *hsv, *mask, *backpoject ,*histimg, *mask_han, *mask_bp, *hand, *sub_han=0;
IplImage *YCR_image, *YCbCr_tep,*YCbCr_dst=0;

CvHistogram* hist = 0;
int backproject_mode =0;
int select_object=0;
int track_object=0;
int show_hist =1;

CvPoint origin;
CvRect selection;
CvRect track_window;
CvBox2D track_box;
CvConnectedComp track_comp;

int hdims = 16;
float hranges_arr[] = {0,180};
float* hranges = hranges_arr;
CvSeq* hull;
int vmin =10, vmax = 256, smin =30;
CvSeq *contour=0;
CvPoint pt0;

CvPoint pt;
CvPoint pt1;
CvMemStorage* storage = 0;
CvRect* faces = 0;
int toward = 0;
int direction = 0;
int fingercount = 0;

//face detect init
const char *classifer = OPENCV_DATA "haarcascade_frontalface_alt.xml";
CvHaarClassifierCascade* cascade = 0;


void mouseCallback(int event, int x, int y, int flags, void* param)
{
    if(!image) return ;
    if(image->origin) y = image->height -y;

    if(select_object)
    {
        ROS_INFO("1");
        selection.x = MIN(x,origin.x);
        selection.y = MIN(y,origin.y);
        selection.width = selection.x + CV_IABS(x- origin.x);
        selection.height = selection.y + CV_IABS(y- origin.y);

        selection.x = MAX(selection.x , 0);
        selection.y = MAX(selection.y , 0);
        selection.width = MIN(selection.width,image->width);
        selection.height = MIN(selection.height, image->height);
        selection.width -= selection.x;
        selection.height -= selection.y;
    }

    switch(event)
    {
        case CV_EVENT_LBUTTONDOWN:
             origin = cvPoint(x, y);
             selection = cvRect(x,y,0,0);
             select_object = 1;
        break;

        case CV_EVENT_LBUTTONUP:
             select_object = 0;
             if(selection.width >0 && selection.height >0) track_object = -1;
        break;
    }

}


int main(int argc, char** argv)
{
    CAM cam;

    //ros init
    ros::init(argc, argv, "OPENCV");
    ros::NodeHandle nh;

    vision_pub = nh.advertise<opencv::vision_msg>("vision",100);

    //cam init
    cam.Cam_init();
    cam.Createimage();
    cam.background_init();
    cam.Camshift_init();

    //face init
    cascade = (CvHaarClassifierCascade*) cvLoad(classifer, 0, 0, 0 );
    storage = cvCreateMemStorage (0);

    cvSetMouseCallback("camshift_image",mouseCallback,0);

    while(ros::ok())
    {
           frame =  cvQueryFrame(input_CAM);
           if(!frame)
           {
               ROS_INFO("STOP");
               break;
           }
           //face_detect_process(frame);
           ///////////////////////skin color ////////////////////////
           cam.Src_To_YCbCr(size,frame);  //// image 1

           ///////////////////////background delete////////////////////
           cam.background_process(); // image 2

           ////////////////////////fusion image/////////////////////////
           cam.Fusion_image(YCR_image_result,skin);

           ////////////////////////fusion2 image/////////////////////////
           cam.Camshift_process();



           ////////////////////////label image//////////////////////////
           if(mask_han !=NULL) cam.Labeled(mask_han);

           //cam.Labeled(sub_image);


           //cvShowImage("Origin", frame);
           //cvShowImage("skin", skin);
           ////cvShowImage("YCR_image_result", YCR_image_result);
           //cvShowImage("sub_image", sub_image);
           //cvShowImage("mask_bp", mask_bp);
           //cvShowImage("mask_han", mask_han);
           cvShowImage("labeled_image", labeled_image);
           //cvShowImage("skin", skin);
           cvShowImage("sub_skin", sub_skin);


           cvShowImage("camshift_image", image);


            if (cvWaitKey(10) == 27)
                break;
    }

    cam.Cam_End();

}
