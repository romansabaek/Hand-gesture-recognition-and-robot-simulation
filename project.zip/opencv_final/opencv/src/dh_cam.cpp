#include "../include/opencv/dh_cam.h"

//command topic



extern ros::Publisher vision_pub;

using namespace std;
using namespace cv;
using namespace BDH_CAM;

extern IplImage *frame,
                *YCR_image_result,*Circle, //2
                *average_image, *sgm,*tmp,*msk,*lower,*upper,*sub_skin, *skin,//background 8
                * src_gray, *roi_image,*sub_roi, //3
                *labeled_image, //1
                *sub_image, *sub_image_final; //2

extern CvCapture * input_CAM;
extern CvSize size;

//camshift
extern IplImage *image, *hue, *hsv, *mask, *backpoject ,*histimg, *mask_han, *mask_bp, *hand, *sub_han;
extern IplImage *YCR_image, *YCbCr_tep,*YCbCr_dst;

extern CvHistogram* hist ;
extern int backproject_mode ;
extern int select_object;
extern int track_object;
extern int show_hist ;

extern CvPoint origin;
extern CvRect selection;
extern CvRect track_window;
extern CvBox2D track_box;
extern CvConnectedComp track_comp;

extern int hdims ;
extern float hranges_arr[];
extern float* hranges;
extern CvSeq* hull;
extern int vmin , vmax, smin ;



//face detect init
extern const char *classifer;
extern CvHaarClassifierCascade* cascade;
extern CvMemStorage* storage ;
extern CvSeq *contour;
extern CvRect* faces;
extern int toward;
extern int direction;
extern CvPoint pt;
extern CvPoint pt0;


extern CvPoint pt1;
extern int fingercount;


bool CAM::Cam_init()
{
    input_CAM = cvCreateCameraCapture(0);

    cvSetCaptureProperty(input_CAM, CV_CAP_PROP_FRAME_WIDTH, Width);
    cvSetCaptureProperty(input_CAM, CV_CAP_PROP_FRAME_HEIGHT, Height);

    frame = cvQueryFrame(input_CAM);
    //cvNamedWindow("Origin", 0);

    //cvResizeWindow("Origin", frame->width, frame->height);

    size = cvSize(frame->width, frame->height);

    if (input_CAM != NULL) return 1;
    else return 0;
}

void CAM::Cam_End()
{
    cvReleaseCapture(&input_CAM);

    cvReleaseImage(&Circle);
    cvReleaseImage(&YCR_image_result);

    cvReleaseImage(&average_image);
    cvReleaseImage(&sgm);
    cvReleaseImage(&tmp);
    cvReleaseImage(&msk);
    cvReleaseImage(&lower);
    cvReleaseImage(&upper);
    cvReleaseImage(&labeled_image);
    cvReleaseImage(&sub_skin);
    cvReleaseImage(&skin);

    cvReleaseImage(&src_gray);
    cvReleaseImage(&roi_image);
    cvReleaseImage(&sub_roi);

    cvReleaseImage(&sub_image);
    cvReleaseImage(&sub_image_final);

    cvReleaseImage(&image);
    cvReleaseImage(&hsv);
    cvReleaseImage(&hue);
    cvReleaseImage(&mask);
    cvReleaseImage(&backpoject);
    cvReleaseImage(&histimg);
    cvReleaseImage(&mask_bp);
    cvReleaseImage(&mask_han);
    cvReleaseImage(&hand);
    cvReleaseImage(&sub_han);

    cvReleaseImage(&YCR_image);
    cvReleaseImage(&YCbCr_tep);
    cvReleaseImage(&YCbCr_dst);

    cvDestroyWindow("Origin");
    cvDestroyWindow("labeled");

}

void CAM::Createimage()
{
    average_image = cvCreateImage(size,IPL_DEPTH_32F,3);
    sgm= cvCreateImage(size,IPL_DEPTH_32F,3);
    tmp= cvCreateImage(size,IPL_DEPTH_32F,3);
    msk= cvCreateImage(size,8,1);
    lower =cvCreateImage(size,IPL_DEPTH_32F,3);
    upper=cvCreateImage(size,IPL_DEPTH_32F,3);
    skin = cvCreateImage(size,8,1);

    labeled_image = cvCreateImage(size,8,3);
    YCR_image_result = cvCreateImage(size,IPL_DEPTH_8U,1);
    YCR_image = cvCreateImage(size,IPL_DEPTH_8U,3);
    YCbCr_tep = cvCreateImage(size, IPL_DEPTH_8U, 1);
    YCbCr_dst = cvCreateImage(size, IPL_DEPTH_8U, 1);
    sub_image = cvCreateImage(size,8,1); //gray sub image
    sub_image_final = cvCreateImage(size,8,3); //frame & rgb sub image

    mask_bp = cvCreateImage(size,8,1);
    mask_han = cvCreateImage(size,8,1);
    hand = cvCreateImage(size,8,3);
}



//카메라 동작시 처음 카메라는 고정 ->> 배경 데이터를 구함
void CAM::background_init()
{


        //더한 후에 나눈다 -> 평균화 작업
        cvSetZero(average_image);
        for(int i=0;i<INIT_TIME;i++)
        {
                frame = cvQueryFrame(input_CAM);
                cvAcc(frame,average_image);
                //cvAcc 함수 : 데이터 누적후 평균값을 이용하여 배경 데이터의 정보를 구함
                //sum(x,y) = sum(x,y) + image(x,y)
        }
        cvConvertScale(average_image,average_image,1.0/INIT_TIME);

        //형재 영상과 평균값의 차 연산
        cvSetZero(sgm); //data init
        for(int i=0;i<INIT_TIME;i++)
        {
            frame = cvQueryFrame(input_CAM);
            cvConvert(frame,tmp);
            cvSub(tmp,average_image,tmp);
            cvPow(tmp,tmp,2.0);//제곱
            cvConvertScale(tmp,tmp,2.0);
            cvPow(tmp,tmp,0.5);// 루트
            cvAcc(tmp,sgm);
        }
        cvConvertScale(sgm,sgm,1.0/INIT_TIME);
}


////////background////////////////////////////////

void CAM::background_process()
{
    double B_PARAM = 1.0 / 30.0;
    double T_PARAM = 1.0 / 100.0; //배경 업데이트 속도 결정
    double zeta = 10.0;

    //lower : 영상의 평균값 과 휘도 진폭값의 차 연산을 구한 후 zeta 만큼 뺀값 (현재영상 보다 밝)
    cvConvert(frame,tmp);
    cvSub(average_image,sgm,lower);
    cvSubS(lower,cvScalarAll(zeta),lower);

     //upper : 영상의 평균값 과 휘도 진폭값을 더한 후 zeta 만큼 더함 (현재 영상보다 어두움)
    cvAdd(average_image,sgm,upper);
    cvAddS(upper,cvScalarAll(zeta),upper);

    //마스크 영상 만들기 :현재 영상의 밝기가 lower upper 사이 범위면 255출력, 영상은 msk 에 저장
    cvInRange(tmp,lower,upper,msk);

    //update msk
    cvSub(tmp,average_image,tmp);
    cvPow(tmp,tmp,2.0);//제곱
    cvConvertScale(tmp,tmp,2.0);
    cvPow(tmp,tmp,0.5);// 루트

    cvRunningAvg(frame,average_image,B_PARAM,msk);
    cvRunningAvg(tmp,sgm,B_PARAM,msk);
    cvNot(msk, msk);
    //cvRunningAvg(tmp, sgm, T_PARAM, msk);
    //open delete noise

    cvCopy(msk,skin,0);


    //opening
    cvErode(skin,skin,0,1);
    cvErode(skin,skin,0,1);
    cvDilate(skin,skin,0,1);
    cvDilate(skin,skin,0,1);
}



void CAM::Pub_data(int x,int direc,int count)
{
    opencv::vision_msg FINGER_TOWARD;

    if((count==0 && direc>80) ||(count==1 && direc>80) )
    {
        FINGER_TOWARD.value = low;
        FINGER_TOWARD.direction = FORWARD;

        if(x> -30 && x<30)
        {
            ROS_INFO(" FORWARD x = %d",x);
            FINGER_TOWARD.mode = FORWARD;
            vision_pub.publish(FINGER_TOWARD);
        }

        else if(x<= -30 )
        {
            ROS_INFO(" FORWARD Left x = %d",x);
            FINGER_TOWARD.mode = RIGHT;
            vision_pub.publish(FINGER_TOWARD);

        }
        else if(x>=30 )
        {
            ROS_INFO("FORWARD  Right x = %d",x);
            FINGER_TOWARD.mode = LEFT;
            vision_pub.publish(FINGER_TOWARD);
        }
    }

    else if((count==0 && direc<=80))
    {
        FINGER_TOWARD.value = low;
        FINGER_TOWARD.direction = BACK;

        if(x> -1 && x<10)
        {
            ROS_INFO(" BACK x = %d",x);
            FINGER_TOWARD.mode = BACK;
            vision_pub.publish(FINGER_TOWARD);
        }

        else if(x<= -1 )
        {
            ROS_INFO(" BACK Left x = %d",x);
            FINGER_TOWARD.mode = RIGHT;
            vision_pub.publish(FINGER_TOWARD);

        }
        else if(x>=10 )
        {
            ROS_INFO("BACK  Right x = %d",x);
            FINGER_TOWARD.mode = LEFT;
            vision_pub.publish(FINGER_TOWARD);
        }

    }


    else if((count==2 && direc>80))
    {
        FINGER_TOWARD.value = middle;
        FINGER_TOWARD.direction = FORWARD;
        if(x> -15 && x<15)
        {
            ROS_INFO(" middle FORWARD x = %d",x);
            FINGER_TOWARD.mode = FORWARD;
            vision_pub.publish(FINGER_TOWARD);
        }

        else if(x<= -15)
        {
            ROS_INFO(" middle Left x = %d",x);
            FINGER_TOWARD.mode = RIGHT;
            vision_pub.publish(FINGER_TOWARD);

        }
        else if(x>=15)
        {
            ROS_INFO(" middle Right x = %d",x);
            FINGER_TOWARD.mode = LEFT;
            vision_pub.publish(FINGER_TOWARD);
        }
    }
    else if((count==3 && direc>80))
    {
        FINGER_TOWARD.value = fast;
        FINGER_TOWARD.direction = FORWARD;
        if(x> -10 && x<10 )
        {
            ROS_INFO(" fast FORWARD x = %d",x);
            FINGER_TOWARD.mode = FORWARD;
            vision_pub.publish(FINGER_TOWARD);
        }

        else if(x<= -10)
        {
            ROS_INFO(" fast Left x = %d",x);
            FINGER_TOWARD.mode = RIGHT;
            vision_pub.publish(FINGER_TOWARD);

        }
        else if(x>=10)
        {
            ROS_INFO(" fast Right x = %d",x);
            FINGER_TOWARD.mode = LEFT;
            vision_pub.publish(FINGER_TOWARD);
        }
    }

    else if(((count==4 && direc>80)))
    {

        ROS_INFO("stop");
        FINGER_TOWARD.mode = STOP;
        vision_pub.publish(FINGER_TOWARD);
    }




}

////labeling
void CAM::Labeled(IplImage* skin) //sub_image -> skin
{


    cvCvtColor(skin, labeled_image,CV_GRAY2BGR);


    CBlobLabeling blob;
    blob.SetParam(skin,LabelingMinimumPixel); // image, minimum pixel
    blob.DoLabeling(); //run labeling


    blob.BlobSmallSizeConstraint(100,100); //100 100
    blob.BlobBigSizeConstraint(350,480); //350 480

    for(int i=0;  i<blob.m_nBlobs; i++)
    {

        //hand area find
        CvRect hand;
        hand.x =0, hand.y=0,hand.width=0,hand.height=0;
        hand.x= blob.m_recBlobs[i].x;
        hand.y= blob.m_recBlobs[i].y;
        hand.width= blob.m_recBlobs[i].width;
        hand.height= blob.m_recBlobs[i].height;

//        if(hand.width<170&&hand.height>190) hand.height = 190;
//        if(hand.width>170&&hand.height>190)
//        {
//            hand.height = 190;
//            hand.width = hand.width;
//        }

        if(hand.width<150&&hand.height>170) hand.height = 170;
        if(hand.width>150&&hand.height>170)
        {
            hand.height = 170;
            hand.width = hand.width;
        }
        ///////////////////////////////////////////////////////////image in labeling
        cvSetImageROI(skin,hand); //binary skin
        //손 영역의 중심 점 찾기//

        //1. 레이블링 된 이미지만 따로 추출
        //skin -> subskin
        sub_skin = cvCreateImage(cvSize(hand.width,hand.height),8,1);

        cvCopy(skin, sub_skin);
        cvResetImageROI(skin);

        //mopology open
        cvDilate(sub_skin,sub_skin,0,1);
        cvErode(sub_skin,sub_skin,0,1);

        //2. 손 영역의 중심 점 찾기
        //center hand point
        int num =0;
        int sum_x, sum_y=0;

        uchar *data_sub = (uchar*) sub_skin->imageData;
        int sub_w = sub_skin->width;
        int sub_h = sub_skin->height;
        int sub_ws = sub_skin->widthStep;

        for(int j=0; j<sub_h;j++)
            for(int i=0;i<sub_w;i++)
            {
                if(data_sub[j*sub_ws +i]==255)
                {
                    sum_x +=i;
                    sum_y +=j;
                    num++;
                }
            }

        //손 가락 개수 찾기 손 중심을 중점으로 큰 원 그리기
        CvPoint fst;
        for(int j=0; j<sub_h; j++)

            for(int i=0;i<sub_w; i++)
            {
                if(data_sub[j*sub_ws +i]==255){ fst.x=i; fst.y=j; i=sub_w; j=sub_h;}
            }


        int rad = (int)sqrt((double) (((int)(sum_x/num) - fst.x) * ((int)(sum_x/num) - fst.x) +
                                      (((int)(sum_y/num) - fst.y) * ((int)(sum_y/num) - fst.y))) ); //distance between center and fst


        //finger dectection

        Circle = cvCreateImage(cvGetSize(sub_skin),8,1);
        cvSetZero(Circle);
        cvCircle(Circle,cvPoint((int)(sum_x/num),(int)(sum_y/num)),(int)(rad/1.5), CV_RGB(255,255,255),6);
        cvAnd(sub_skin,Circle,sub_skin ,0);


        CBlobLabeling label;
        label.SetParam(sub_skin,50); // image, minimum pixel
        label.DoLabeling(); //run labeling


       // show test
        if(label.m_nBlobs ==1)
        {
            fingercount =0;
            //ROS_INFO("FINGER 0");
        }
        else if(label.m_nBlobs ==2)
        {
            fingercount =1;
            //ROS_INFO("FINGER 1");
        }
        else if(label.m_nBlobs ==3)
        {
            fingercount =2;
           // ROS_INFO("FINGER 2");
        }
        else if(label.m_nBlobs ==4)
        {
            fingercount =3;
            //ROS_INFO("FINGER 3");
        }
        else if(label.m_nBlobs ==5)
        {
            fingercount =4;
            //ROS_INFO("FINGER 4");
        }
        else
        {
            fingercount =0;
            //ROS_INFO("FINGER 0");
        }

        //count=0;
        //count = cvFindContours(sub_skin, storage, &contour, sizeof(CvContour),  CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, cvPoint(0,0));



        /////draw circle, rect
        CvPoint pt1 = cvPoint(blob.m_recBlobs[i].x,blob.m_recBlobs[i].y );
        CvPoint pt2 = cvPoint(pt1.x + blob.m_recBlobs[i].width, pt1.y + blob.m_recBlobs[i].height);
        CvScalar color = cvScalar(0,0,255); //B, G, R
        cvDrawRect(labeled_image,pt1,pt2,color,2); //pt1 = start     pt2 = end  color   thickness

        //draw center
        cvCircle(labeled_image,cvPoint(pt1.x + (int)(sum_x/num), pt1.y+ (int)(sum_y/num)),5,CV_RGB(0,255,0),5);


        //draw line & big circle
        //cvCircle(labeled_image,cvPoint(pt1.x + (int)(sum_x/num), pt1.y+ (int)(sum_y/num)),(int)(rad/1.5),CV_RGB(255,0,0),6);
        toward = (sum_x/num) - fst.x;
        direction = (sum_y/num) - fst.y;


        if(direction>90) cvLine(labeled_image,cvPoint(pt1.x + fst.x, pt1.y+fst.y),cvPoint(pt1.x + (int)(sum_x/num), pt1.y+ (int)(sum_y/num)),CV_RGB(255,255,0),4);


        //print
        //ROS_INFO("x = %d, y= %d",(sum_x/num) - fst.x,(sum_y/num) - fst.y);

        //ros pub
        Pub_data(toward,direction,fingercount);


    }



}




////////////////////////face detect///////////////////////////////////



void CAM::face_detect_process(IplImage *src_img)
{
    //process
    CvSeq* faces = 0;
    faces = cvHaarDetectObjects(src_img, cascade, storage, 2.0, 1, 0);

    //검출된 모든 face에 대한 반복문
    for(int i=0; i<faces->total; i++)
    {
    //face 영역 가져오기
        CvRect *r = 0;
        r = (CvRect*) cvGetSeqElem(faces, i);

        unsigned char *p1;
        int x, y;
        for(y = 0; y < r->height; ++y)
        {
            p1 = (unsigned char*)src_img->imageData + src_img->widthStep* (y +r->y) + 3* r->x;

            for(x=0; x<r->width;++x)
            {
                *(p1 ++) = 0;
                *(p1 ++) = 0;
                *(p1 ++) = 0;
            }
        }
        //frame에 face 영역 그리기
        cvRectangle(src_img, cvPoint(r->x, r->y), cvPoint(r->x+r->width, r->y+r->height), cvScalar(0,255,0), 3, CV_AA, 0);
    }
}






void CAM::Src_To_YCbCr(CvSize size, IplImage  *src_image)
{

    cvCvtColor(src_image, YCR_image,CV_BGR2YCrCb);
    cvInRangeS(YCR_image,Scalar(0,133,77),Scalar(255,173,127),YCbCr_dst);


    //open
    for(int iteration = 1; iteration <= 5; ++iteration)
    {
         cvMorphologyEx(YCbCr_dst, YCR_image_result, YCbCr_tep , NULL, CV_MOP_OPEN, iteration);
    }

    //close
    for(int iteration = 1; iteration <= 5; ++iteration)
    {
         cvMorphologyEx(YCbCr_dst, YCR_image_result, YCbCr_tep , NULL, CV_MOP_CLOSE, iteration);
    }


}


//image add
void CAM::Fusion_image(IplImage* a, IplImage* b)
{

    IplImage* sub_image3= cvCreateImage(size,8,3); //rgb sub image


    cvAnd(a,b,sub_image);

    //open
    for(int iteration = 1; iteration <= 5; ++iteration)
    {
        cvErode(sub_image,sub_image,0,1);
    }
    for(int iteration = 1; iteration <= 5; ++iteration)
    {
        cvDilate(sub_image,sub_image,0,1);
    }

    cvCvtColor(sub_image, sub_image3,CV_GRAY2RGB);
    cvAnd(sub_image3,frame,sub_image_final);

    cvReleaseImage(&sub_image3);

}




/////////////////camshift/////////////
void CAM::Camshift_init()
{

    ROS_INFO("cam shift init");
    image = cvCreateImage(size,8,3);
    image->origin = frame->origin;

    hsv = cvCreateImage(size,8,3);
    hue = cvCreateImage(size,8,1);
    mask = cvCreateImage(size,8,1);
    backpoject = cvCreateImage(size,8,1);

    hist = cvCreateHist(1, &hdims, CV_HIST_ARRAY, &hranges,1);

    histimg = cvCreateImage(cvSize(320,200),8,3);
    cvZero(histimg);

    cvNamedWindow("camshift_image",0);
    cvResizeWindow("camshift_image", frame->width, frame->height);
}



void CAM::Camshift_process()
{
    int bin_w;

    cvCopy(frame, image, 0);
    cvCvtColor(image,hsv,CV_BGR2HSV );

    if(track_object)
    {
        int _vmin = vmin, _vmax = vmax;
        cvInRangeS(hsv, cvScalar(0,smin,MIN(_vmin,_vmax),0),cvScalar(180,256,MAX(_vmin,_vmax),0), mask );
        cvSplit(hsv, hue,0,0,0);

        //roi ok
        if(track_object <0)
        {
            float max_val = 0.f;
            cvSetImageROI(hue, selection);
            cvSetImageROI(mask, selection);

            cvCalcHist(&hue, hist, 0 , mask);

            cvGetMinMaxHistValue(hist, 0, &max_val,0,0);

            cvConvertScale(hist->bins, hist->bins, max_val ? 255. / max_val : 0.,0  );
            cvResetImageROI(hue);
            cvResetImageROI(mask);

            track_window = selection;

            track_object =1;
            cvZero(histimg);

        }

        cvCalcBackProject(&hue, backpoject, hist);
        cvAnd(backpoject, mask, backpoject, 0);

        cvCamShift(backpoject, track_window, cvTermCriteria(CV_TERMCRIT_EPS | CV_TERMCRIT_ITER,10,1), &track_comp, &track_box);

        track_window = track_comp.rect;



        pt.x = (int)(track_box.center.x);
        pt.y = (int)(track_box.center.y);

        //CvPoint pt1;
        pt1 = cvPoint(track_window.x , (int)(track_window.y));


        cvSetZero(mask_bp);
        cvCircle(mask_bp, pt, (int)(0.8*track_box.size.width), CV_RGB(255,255,255),-1);
        //cvDrawRect(mask_bp, pt1, cvPoint(pt1.x + (int)(track_window.width),  pt1.y + track_window.height), CV_RGB(255,255,255), -1);
        cvNot(mask_bp,mask_bp);


        //add 2 image
        cvAnd(sub_image, mask_bp, mask_han,0);
        cvZero(hand);
        cvCopy(image, hand, mask_han);

        //opening
        for(int iteration = 1; iteration <= 5; ++iteration)
        {
            cvErode(mask_han,mask_han,0,1);
        }
        for(int iteration = 1; iteration <= 5; ++iteration)
        {
            cvDilate(mask_han,mask_han,0,1);
        }

        if(!image->origin)
        {
            track_box.angle = -track_box.angle;
        }

        cvEllipseBox(image, track_box, CV_RGB(255,0,0), 3, CV_AA,0);

    }


    if(select_object && selection.width > 0 && selection.height >0)
    {
        cvSetImageROI(image, selection);
        cvXorS(image, cvScalarAll(255), image,0);
        cvResetImageROI(image);
    }
}


void CAM:: Convexhull()
{
    ///////////////////cvconvexhull

    pt0.x = 0, pt0.y =0;
    double fMaxDist =0.0;
    CvPoint corner; CvPoint end_pt;
    corner = cvPoint(0,0);

    if(contour->total!=0)
    {
        ROS_INFO("HULL");
        hull = cvConvexHull2(contour, 0, CV_COUNTER_CLOCKWISE,0);

        for(int x=0; x<hull->total; x++)
        {
            CvPoint hull_pt = **CV_GET_SEQ_ELEM(CvPoint*, hull,x);
            if(pt0.x==0 && pt0.y ==0)
            {
                pt0 = hull_pt; end_pt = pt0;
            }
            cvLine(hand, pt0, hull_pt, CV_RGB(255,0,0),2,8);
            pt0 = hull_pt;

            if(x == hull->total-1) cvLine(hand,hull_pt,end_pt,CV_RGB(255,0,0),2,8);

            CvPoint cor_pt = **CV_GET_SEQ_ELEM(CvPoint*,hull,x);
            double fDist = sqrt((double)((pt.x- cor_pt.x) * (pt.x - cor_pt.x)
                                         + (pt.y - cor_pt.y) *(pt.y- cor_pt.y)));


            if(fDist > fMaxDist)
            {
                corner = cor_pt;
                fMaxDist = fDist;
            }
        }

    }

//    CvPoint c_pt, c_pt1, r_pt1;
//    c_pt = cvPoint((int)(pt.x - track_box.size.width),(int)(pt.y - track_box.size.width));
//    c_pt1 = cvPoint((int)(pt.x + track_box.size.width),(int)(pt.y + track_box.size.width));
//    r_pt1 = cvPoint((int)(pt1.x + track_box.size.width),(int)(pt1.y + track_box.size.height));

//    CvRect r_roi;
//    r_roi.x = (int)MIN(pt1.x,c_pt.x);
//    r_roi.y = (int)MIN(pt1.y,c_pt.y);
//    r_roi.width = (int)(MAX(r_pt1.x,c_pt.x) - r_roi.x);
//    r_roi.height = (int)(MAX(r_pt1.y,c_pt.y) - r_roi.y);

//    if(r_roi.x <0)  r_roi.x =0;
//    if(r_roi.y <0)  r_roi.y =0;
//    if(r_roi.width <0)  r_roi.width =640;
//    if(r_roi.height <0) r_roi.height =840;

//    cvSetImageROI(mask_han, r_roi);
//    sub_han = cvCreateImage(cvSize(mask_han->roi->width,mask_han->roi->height),8,1);
//    cvCopy(mask_han, sub_han);
//    cvResetImageROI(mask_han);

//    Circle = cvCreateImage(cvGetSize(sub_han),8,1);
//    cvSetZero(Circle);
//    cvCircle(Circle,cvPoint(pt.x - r_roi.x, pt.y - r_roi.y),(int)(fMaxDist*0.8), CV_RGB(255,255,255),6);
//    cvAnd(sub_han,Circle,sub_han ,0);



}


















