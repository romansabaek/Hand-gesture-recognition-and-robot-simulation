#include "ros/ros.h"
#include "opencv/vision_msg.h"



int main(int argc, char**argv)
{
    ros::init(argc, argv, "vision_sub_test");
	ros::NodeHandle nh;


	ros::spin();
	return 0;

}
