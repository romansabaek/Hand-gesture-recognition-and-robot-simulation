#include "ros/ros.h"
#include "std_msgs/String.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>
#include <getopt.h>
#include <fcntl.h>
#include <iostream>
#include <vector>
#include "opencv/pub_msg.h"
#include "std_msgs/Float64.h"
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/Twist.h"
#include "opencv/vision_msg.h"


#define FORWARD 1
#define STOP 2
#define LEFT 3
#define RIGHT 4
#define BACK 5
#define low  6
#define middle 7
#define fast 8

ros::Publisher gazeo_pub_atlaswalk;
ros::Publisher cmd_vel_pub;



void motion_callback(opencv::vision_msg data);

int angle = 0;
int count[5]={0,};

int _getch()
{
    struct termios oldt, newt;
    int ch;
    tcgetattr( STDIN_FILENO, &oldt );
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr( STDIN_FILENO, TCSANOW, &newt );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldt );
    return ch;
}




int main(int argc, char**argv)
{
    ros::init(argc, argv, "pub_test");
    ros::NodeHandle nh;

    cmd_vel_pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/teleop",100);
    ros::Subscriber opencv_msg_sub = nh.subscribe("vision",100,motion_callback);
    opencv::pub_msg data;


    ros::Rate loop_rate(10);
    ros::spin();
    return 0;

}



void motion_callback(const opencv::vision_msg data)
{

    geometry_msgs::Twist base_cmd;


    if(data.direction == FORWARD)
    {
        if(data.mode == FORWARD && data.value == low)
        {
            base_cmd.linear.x = 0.25;
            ROS_INFO("low GO");
        }

        else if(data.mode == FORWARD && data.value == middle)
        {
            base_cmd.linear.x = 0.5;
            ROS_INFO("middle GO");
        }

        else if(data.mode == FORWARD && data.value == fast)
        {
            base_cmd.linear.x = 1;
            ROS_INFO("fast GO");
        }

        //////left
        else if(data.mode == LEFT && data.value == low)
        {
            base_cmd.linear.x = 0.25;
            base_cmd.angular.z = 0.75;
            ROS_INFO("low LEFT");

        }
        else if(data.mode == LEFT && data.value == middle)
        {
            base_cmd.linear.x = 0.5;
            base_cmd.angular.z = 0.75;
            ROS_INFO("middle LEFT");
        }

        else if(data.mode == LEFT && data.value == fast)
        {
            base_cmd.linear.x = 1;
            base_cmd.angular.z = 0.75;
            ROS_INFO("fast LEFT");
        }

        //RIGHT
        else if(data.mode == RIGHT && data.value == low)
        {
            base_cmd.linear.x = 0.25;
            base_cmd.angular.z = -0.75;
            ROS_INFO("low RIGHT");

        }
        else if(data.mode == RIGHT && data.value == middle)
        {
            base_cmd.linear.x = 0.5;
            base_cmd.angular.z = -0.75;
            ROS_INFO("middle RIGHT");
        }

        else if(data.mode == RIGHT && data.value == fast)
        {
            base_cmd.linear.x = 1;
            base_cmd.angular.z = -0.75;
            ROS_INFO("fast RIGHT");
        }
        else if(data.mode == STOP)
        {
            base_cmd.linear.x = 0;
            ROS_INFO("STOP");
        }
    }


    else if(data.direction ==BACK)
    {
        if(data.mode == BACK && data.value == low)
        {
            base_cmd.linear.x = -0.25;
            ROS_INFO("BACK  GO");
        }

        else if(data.mode == LEFT && data.value == low)
        {
            base_cmd.linear.x = -0.25;
            base_cmd.angular.z = 0.75;
            ROS_INFO("BACK  LEFT ");
        }

        else if(data.mode == RIGHT && data.value == low)
        {
            base_cmd.linear.x = -0.25;
            base_cmd.angular.z = -0.75;
            ROS_INFO("BACK  RIGHT");
        }
        else if(data.mode == STOP)
        {
            base_cmd.linear.x = 0;
            ROS_INFO("STOP");
        }

    }

    cmd_vel_pub.publish(base_cmd);


}











