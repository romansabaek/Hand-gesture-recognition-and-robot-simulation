#ifndef BDH_camlib_H
#define BDH_camlib_H


#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include<opencv2/objdetect/objdetect.hpp>
#include "bloblabeling.h"
#include "opencv/vision_msg.h"
#include "std_msgs/Float64.h"
#include "geometry_msgs/Pose.h"


#include <math.h>
#include <iostream>
#include <vector>
#include<algorithm>
#include<cstdlib>
#include<ctype.h>

//define
#define Width 640
#define Height 480
#define Threshold 127
#define LabelingMinimumPixel 100
#define INIT_TIME 100
#define OPENCV_DATA "/usr/share/opencv/haarcascades/"


//gazebo
#define FORWARD 1
#define STOP 2
#define LEFT 3
#define RIGHT 4
#define BACK 5

#define low  6
#define middle 7
#define fast 8


using namespace std;
using namespace cv;


namespace BDH_CAM{

    class CAM
    {

    public:

        void Camshift_process();
        void Camshift_init();
        void Fusion_image(IplImage* a, IplImage* b);
        void Src_To_YCbCr(CvSize size, IplImage  *src_image);
        void face_detect_process(IplImage *src_img);
        void Labeled(IplImage* skin) ;
        void background_process();
        void background_init();
        void Createimage();
        void Cam_End();
        bool Cam_init();
        void Pub_data(int x,int direc,int count);
        void Convexhull();

    private:

    };




}



#endif
