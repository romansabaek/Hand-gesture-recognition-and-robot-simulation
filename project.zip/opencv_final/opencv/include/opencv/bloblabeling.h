//#pragma once

#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
//#include <highgui.h>
enum{FALSE,TRUE};

typedef struct
{
    bool	bVisitedFlag;
    CvPoint ptReturnPoint;
} Visited;

class  CBlobLabeling
{
public:
    CBlobLabeling(void);
public:
    ~CBlobLabeling(void);

public:
    cv::Mat		m_Image;
    int			m_nThreshold;
    Visited*	m_vPoint;
    int			m_nBlobs;
    CvRect*		m_recBlobs;
    cv::Point*	m_BlobPointHigh;
    cv::Point*	m_BlobPointLow;


public:
    void		SetParam(cv::Mat image, int nThreshold);

    void 		FindLine(int nLabel);
    void 		FindLine_Horizontal(int nLabel);
    void		DoLabeling();

private:
    int 	Labeling(cv::Mat image, int nThreshold);
    void	 InitvPoint(int nWidth, int nHeight);
    void	 DeletevPoint();
    void	 DetectLabelingRegion(int nLabelNumber, unsigned char *DataBuf, int nWidth, int nHeight);
    int		_Labeling(unsigned char *DataBuf, int nWidth, int nHeight, int nThreshold);

    int		__NRFIndNeighbor(unsigned char *DataBuf, int nWidth, int nHeight, int nPosX, int nPosY, int *StartX, int *StartY, int *EndX, int *EndY );
    int		__Area(unsigned char *DataBuf, int StartX, int StartY, int EndX, int EndY, int nWidth, int nLevel);

    /******************************************************************/

public:
    void	BlobSmallSizeConstraint(int nWidth, int nHeight);
private:
    void	_BlobSmallSizeConstraint(int nWidth, int nHeight, CvRect* rect, int* nRecNumber);

public:
    void	BlobBigSizeConstraint(int nWidth, int nHeight);
private:
    void	_BlobBigSizeConstraint(int nWidth, int nHeight, CvRect* rect, int* nRecNumber);
};
